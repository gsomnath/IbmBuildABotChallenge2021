package com.example.demo;

import java.io.UnsupportedEncodingException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.client.RestTemplate;

@Controller
public class DemoController {
	
	@Autowired
	private RestTemplate restTemplate;
	
	@Autowired
	DoctorAppointmentService doctorAppointmentService;
	
	 @GetMapping("/")
	    public String index() {
	        return "index.html";
	    }
	 
	
	 @PostMapping(path= "/createPatientProfile", consumes = "application/json", produces = { MediaType.APPLICATION_JSON_VALUE})
	    public ResponseEntity<Object> createPatientProfile(@RequestBody Object cust) throws URISyntaxException{
		 
		 final String baseUrl = "http://desktop-7loqhqo:7800/dummyhealthcareops/v1/createPatientProfile";
		    URI uri = new URI(baseUrl);
		 
		 ResponseEntity<Object> result = restTemplate.postForEntity(uri, cust, Object.class);
		 // System.out.print("here i am");
	       
	        return result;
	    }

	 @PostMapping(path= "/bookAnAppt", consumes = "application/json", produces = { MediaType.APPLICATION_JSON_VALUE})
	    public ResponseEntity<Object> bookAnAppt(@RequestBody Object cust) throws URISyntaxException{
		 
		 final String baseUrl = "http://desktop-7loqhqo:7800/dummyhealthcareops/v1/bookAnAppt";
		    URI uri = new URI(baseUrl);
		 
		 ResponseEntity<Object> result = restTemplate.postForEntity(uri, cust, Object.class);
		 // System.out.print("here i am");
	       
	        return result;
	    }
	 
	 @PostMapping(path= "/searchPatientProfile", consumes = "application/json", produces = { MediaType.APPLICATION_JSON_VALUE})
	    public ResponseEntity<Object> searchPatientProfile(@RequestParam String phnNo,@RequestBody  Object cust) throws URISyntaxException{
		 
		 final String baseUrl = "http://desktop-7loqhqo:7800/dummyhealthcareops/v1/searchPatientProfile" + "?phnNo=" +phnNo;
		    URI uri = new URI(baseUrl);
		 
		 ResponseEntity<Object> result = restTemplate.postForEntity(uri, cust, Object.class);
		 // System.out.print("here i am");
	       
	        return result;
	    }
	 
	 	@PostMapping(path= "/scripts/doctorAppointmentHTTP" ,  consumes = "application/json", produces = { MediaType.APPLICATION_JSON_VALUE})
	    public ResponseEntity<ServiceStatus> doctorAppointment(@RequestBody DocApptReq body /*@RequestParam String patientName, @RequestParam String email, @RequestParam String phnNumber, @RequestParam String dob,
	    		@RequestParam String gender, @RequestParam String doctor, @RequestParam String date, @RequestParam String slot*/) throws URISyntaxException{
		 
		 // String resString = "";
		/* final String baseUrl = "https://localhost:8099/scripts/doctorAppointmentHTTP?unlockMachine=false&patientName=" + encodeValue(patientName) + "&email=" + encodeValue(email) + 
				 "&phnNumber=" + encodeValue(phnNumber) + "&=dob" + encodeValue(dob) + "&gender=" + encodeValue(gender) + 
				 "&doctor=" + encodeValue(doctor) + "&date=" + encodeValue(date) + "&slot=" + encodeValue(slot) ; */
	 		System.out.println("body ->" +body.toString());
	 		
	 		final String baseUrl = "https://localhost:8099/scripts/doctorAppointmentHTTP?unlockMachine=false&patientName=" + encodeValue(body.getName().toString()) + "&email=" + encodeValue(body.getEmail().toString()) + 
					 "&phnNumber=" + encodeValue(body.getPhoneno().toString()) + "&=dob" + encodeValue(body.getDob().toString()) + "&gender=" + encodeValue(body.getGender().toString()) + 
					 "&doctor=" + encodeValue(body.getSpecialityname().toString()) + "&date=" + encodeValue(body.getAppointmentdate().toString()) + "&slot=" + encodeValue(body.getTime().toString()) ;
		 
		 System.out.println("baseUrl ->" +baseUrl);
		 
		 URI uri = new URI(baseUrl);

		    doctorAppointmentService.doctorAppointmentAsyncCall(uri);
		 		    
		    ServiceStatus serviceStatus = new ServiceStatus(0, "successfully creates the appointment.");
		    
		     return  new ResponseEntity<ServiceStatus>(serviceStatus,
		               HttpStatus.CREATED);
	    }
	 	
	 	private String encodeValue(String value) {
	 		
	 		String retStr = "";
	 	    try {
	 	    	retStr =  URLEncoder.encode(value, StandardCharsets.UTF_8.toString());
			} catch (UnsupportedEncodingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	 	    
	 	    return retStr;
	 	}
	 	
	 	
}
