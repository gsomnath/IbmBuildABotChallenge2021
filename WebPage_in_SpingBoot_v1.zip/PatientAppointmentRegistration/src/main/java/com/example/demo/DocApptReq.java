package com.example.demo;

public class DocApptReq {
	
	private String dob;
	
	//@JsonProperty("Name")
	private String name;
	private String gender;
	private String phoneno;
	private String email;
	private String appointmentdate;
	private String time;
	private String specialisttype;
	private String specialityname;
	public String getDob() {
		return dob;
	}
	public void setDob(String dob) {
		this.dob = dob;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getPhoneno() {
		return phoneno;
	}
	public void setPhoneno(String phoneno) {
		this.phoneno = phoneno;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getAppointmentdate() {
		return appointmentdate;
	}
	public void setAppointmentdate(String appointmentdate) {
		this.appointmentdate = appointmentdate;
	}
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}
	public String getSpecialisttype() {
		return specialisttype;
	}
	public void setSpecialisttype(String specialisttype) {
		this.specialisttype = specialisttype;
	}
	public String getSpecialityname() {
		return specialityname;
	}
	public void setSpecialityname(String specialityname) {
		this.specialityname = specialityname;
	}
	@Override
	public String toString() {
		return "DocApptReq [dob=" + dob + ", name=" + name + ", gender=" + gender + ", phoneno=" + phoneno + ", email="
				+ email + ", appointmentdate=" + appointmentdate + ", time=" + time + ", specialisttype="
				+ specialisttype + ", specialityname=" + specialityname + "]";
	}
	
	
	
}
