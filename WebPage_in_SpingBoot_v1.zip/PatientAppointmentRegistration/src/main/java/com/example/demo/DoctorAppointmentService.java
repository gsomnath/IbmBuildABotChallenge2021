package com.example.demo;

import java.net.URI;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
public class DoctorAppointmentService {
	
	@Autowired
	private RestTemplate restTemplate;

	@Async
 	public void doctorAppointmentAsyncCall(URI uri) {
 		ResponseEntity<Object> result = restTemplate.getForEntity(uri,Object.class);
 	}

}
